﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCCleaner.Controls.Common
{
    public class ListItem
    {
        public int ItemId
        {
            get;
            set;
        }

        public string ItemText
        {
            get;
            set;
        }
    }
}
