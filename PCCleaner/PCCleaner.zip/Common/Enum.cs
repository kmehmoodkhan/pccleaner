﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCCleaner.Common
{
    public enum BrowserType { Microsoft = 1, Others = 2 };

    public enum BrowserFeatures
    {
        Cache = 1,
        InternetHistory = 2,
        Cookies = 3,
        DownloadHistory = 4,
        LastDownloadLocation = 5,
        Session = 6,
        SitePreferences = 7,
        SavedFormInformation = 8,
        SavedPassword = 9,
        CompactDatabases = 10
    }
}
