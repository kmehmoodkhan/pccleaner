﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCCleaner.Common
{
    public class SearchCriteria
    {
        public int SearchArea
        {
            get;
            set;
        }
        public int FeatureId
        {
            get;
            set;
        }
    }
}
