﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PCCleaner.Properties;
using PCCleaner.Controls.Common;
using PCCleaner.Common;

namespace PCCleaner.Controls
{
    public partial class UCEdge : UserControl,IBrowserFeature
    {
        bool _checkAll = false;
        public bool CheckedAll
        {
            get
            {
                return _checkAll;
            }
            set
            {
                _checkAll = value;
            }
        }

        //public List<ListItem> SelectedItems
        //{
        //    get
        //    {
        //        return this.chkListEdge.SelectedValue;
        //    }
        //}

        public UCEdge()
        {
            InitializeComponent();

            this.EdgeHeading.HeadingLabel = "Microsoft Edge";
            this.EdgeHeading.HeadingImage = Resources.Edge;
            this.EdgeHeading.IconClick += EdgeHeading_IconClick;

            LoadItems();
        }

        public void LoadItems()
        {
            this.chkListEdge.Items.Clear();
            List<ListItem> list = Navigators.GetBrowserFeatures();
            
            ((ListBox)this.chkListEdge).DataSource = list;
            ((ListBox)this.chkListEdge).DisplayMember = "ItemText";
            ((ListBox)this.chkListEdge).ValueMember = "ItemId";
        }

        private void EdgeHeading_IconClick(object sender, EventArgs e)
        {
            if (CheckedAll == false)
            {
                CheckedAll = true;

                for (int i = 0; i < this.chkListEdge.Items.Count; i++)
                {
                    this.chkListEdge.SetItemChecked(i, true);
                }
            }
            else
            {
                CheckedAll = false;

                for (int i = 0; i < this.chkListEdge.Items.Count; i++)
                {
                    this.chkListEdge.SetItemChecked(i, false);
                }
            }
        }
    }
}
